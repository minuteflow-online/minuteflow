/**
 * MinuteFlow Chrome Extension — Background Service Worker
 *
 * Responsibilities:
 * 1. Auto-capture screenshots on task start/end and at random intervals
 * 2. Poll for remote capture requests from admin
 * 3. Poll for new messages and relay to content script as toast notifications
 * 4. Upload screenshots to Supabase Storage in background
 * 5. Send heartbeat to server so admin knows extension is active
 */

importScripts('supabase.js');

const DB = globalThis.MinuteFlowDB;

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
const CONFIG = {
  // Polling interval for capture requests and messages (ms)
  POLL_INTERVAL_MS: 5000,

  // Heartbeat interval (ms) — tells server the extension is alive
  HEARTBEAT_INTERVAL_MS: 30000,

  // Random check-in screenshot interval range (ms)
  // Between 3 and 8 minutes — randomized so VAs can't game it
  CHECKIN_MIN_MS: 3 * 60 * 1000,
  CHECKIN_MAX_MS: 8 * 60 * 1000,

  // Extension version
  VERSION: '1.0.2',
};

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let pollingIntervalId = null;
let heartbeatIntervalId = null;
let checkinTimeoutId = null;
let currentTaskLogId = null; // The active time_log.id we're tracking

// ---------------------------------------------------------------------------
// Screenshot Capture
// ---------------------------------------------------------------------------

/**
 * Capture the visible area of the currently active tab.
 * Returns a Blob (PNG image).
 */
async function captureActiveTab() {
  try {
    // Get the current active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) {
      console.warn('[MinuteFlow] No active tab found');
      return null;
    }

    // chrome://*, edge://* etc. can't be captured
    if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://') || tab.url.startsWith('edge://'))) {
      console.warn('[MinuteFlow] Cannot capture browser internal page');
      return null;
    }

    // Capture visible tab as data URL (PNG)
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'png',
      quality: 90,
    });

    // Convert data URL to Blob
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return blob;
  } catch (err) {
    console.error('[MinuteFlow] Capture failed:', err.message);
    return null;
  }
}

/**
 * Capture screenshot and upload to Supabase Storage + create DB record.
 *
 * @param {string} screenshotType - 'start' | 'progress' | 'end' | 'remote' | 'manual'
 * @param {number|null} logId - The time_log.id to associate with
 * @param {number|null} captureRequestId - If this is a remote capture
 * @returns {object|null} The created task_screenshots row, or null on failure
 */
async function captureAndUpload(screenshotType = 'manual', logId = null, captureRequestId = null) {
  const session = await DB.getSession();
  if (!session) {
    console.warn('[MinuteFlow] Not authenticated, skipping capture');
    return null;
  }

  const blob = await captureActiveTab();
  if (!blob) return null;

  try {
    const resolvedLogId = logId || currentTaskLogId;
    if (!resolvedLogId) {
      console.warn('[MinuteFlow] No active log ID, skipping upload');
      return null;
    }
    const formData = new FormData();
    formData.append('file', blob, 'screenshot.png');
    formData.append('userId', session.user.id);
    formData.append('logId', String(resolvedLogId));
    formData.append('screenshotType', screenshotType);
    if (captureRequestId) formData.append('captureRequestId', String(captureRequestId));

    const res = await fetch('https://minuteflow.click/api/upload-screenshot', {
      method: 'POST',
      body: formData,
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('[MinuteFlow] Upload failed:', errText);
      return null;
    }

    const data = await res.json();
    const screenshot = data.screenshot;
    console.log('[MinuteFlow] Screenshot -> Drive:', screenshotType, screenshot && screenshot.drive_file_id);
    return screenshot || null;
  } catch (err) {
    console.error('[MinuteFlow] Upload failed:', err.message);
    return null;
  }
}

// ---------------------------------------------------------------------------
// Random Check-in Timer
// ---------------------------------------------------------------------------

/**
 * Schedule the next random check-in screenshot.
 * Interval is randomized between CHECKIN_MIN_MS and CHECKIN_MAX_MS.
 */
function scheduleNextCheckin() {
  if (checkinTimeoutId) {
    clearTimeout(checkinTimeoutId);
    checkinTimeoutId = null;
  }

  const delay = CONFIG.CHECKIN_MIN_MS +
    Math.random() * (CONFIG.CHECKIN_MAX_MS - CONFIG.CHECKIN_MIN_MS);

  console.log(`[MinuteFlow] Next check-in in ${Math.round(delay / 1000)}s`);

  // Use chrome.alarms for reliability (service worker may sleep)
  chrome.alarms.create('minuteflow-checkin', {
    delayInMinutes: delay / 60000,
  });
}

/**
 * Stop check-in timer
 */
function cancelCheckin() {
  chrome.alarms.clear('minuteflow-checkin');
  chrome.alarms.clear('minuteflow-1min');
  chrome.alarms.clear('minuteflow-3min');
  if (checkinTimeoutId) {
    clearTimeout(checkinTimeoutId);
    checkinTimeoutId = null;
  }
}

// Handle all alarm fires in a single listener
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'minuteflow-1min') {
    console.log('[MinuteFlow] 1-minute capture triggered');
    if (currentTaskLogId) {
      await captureAndUpload('progress', currentTaskLogId);
    }
    return;
  }

  if (alarm.name === 'minuteflow-3min') {
    console.log('[MinuteFlow] 3-minute capture triggered');
    if (currentTaskLogId) {
      await captureAndUpload('progress', currentTaskLogId);
    }
    return;
  }

  if (alarm.name === 'minuteflow-checkin') {
    console.log('[MinuteFlow] Random check-in capture triggered');
    await captureAndUpload('progress', currentTaskLogId);
    // Schedule next one (only if we still have an active task)
    if (currentTaskLogId) {
      scheduleNextCheckin();
    }
  }

  if (alarm.name === 'minuteflow-keepalive') {
    // Ensure auth is still valid, and revive polling if service worker was killed
    const session = await DB.ensureAuth();
    if (session && !pollingIntervalId) {
      console.log('[MinuteFlow] Service worker revived — restarting polling');
      startPolling();
    }
  }
});

// ---------------------------------------------------------------------------
// Task Lifecycle
// ---------------------------------------------------------------------------

/**
 * Called when a task starts. Takes screenshots on a specific schedule:
 *   1. Immediately (task start)
 *   2. 1 minute after
 *   3. 3 minutes after
 *   4. Then random intervals (3-8 min)
 */
async function onTaskStart(logId) {
  currentTaskLogId = logId;
  await chrome.storage.local.set({ mf_active_log_id: logId });

  console.log(`[MinuteFlow] Task started: log_id=${logId}`);

  // 1. Immediate screenshot (task start)
  await captureAndUpload('start', logId);

  // 2. Screenshot at 1 minute
  chrome.alarms.create('minuteflow-1min', { delayInMinutes: 1 });

  // 3. Screenshot at 3 minutes
  chrome.alarms.create('minuteflow-3min', { delayInMinutes: 3 });

  // 4. Random check-ins start after the 3-minute mark
  //    Schedule first random one between 5-8 min from task start
  const firstRandomDelay = (5 + Math.random() * 3) * 60 * 1000;
  chrome.alarms.create('minuteflow-checkin', { delayInMinutes: firstRandomDelay / 60000 });
}

/**
 * Called when a task ends. Takes end screenshot and stops check-in timer.
 */
async function onTaskEnd(logId) {
  console.log(`[MinuteFlow] Task ended: log_id=${logId || currentTaskLogId}`);

  // Take end screenshot
  await captureAndUpload('end', logId || currentTaskLogId);

  // Stop check-in timer
  cancelCheckin();

  currentTaskLogId = null;
  await chrome.storage.local.remove('mf_active_log_id');
}

// ---------------------------------------------------------------------------
// Polling: Remote Capture Requests + Messages
// ---------------------------------------------------------------------------

/**
 * Check for pending capture requests targeted at this user
 */
async function pollCaptureRequests() {
  const session = await DB.getSession();
  if (!session) return;

  try {
    const requests = await DB.query('capture_requests', {
      filters: `target_user_id=eq.${session.user.id}&status=eq.pending&order=created_at.asc`,
    });

    if (!requests || requests.length === 0) return;

    for (const req of requests) {
      console.log(`[MinuteFlow] Remote capture request: ${req.id}`);

      // Take the screenshot
      const screenshot = await captureAndUpload('remote', req.log_id, req.id);

      // Update the request status
      await DB.query('capture_requests', {
        method: 'PATCH',
        filters: `id=eq.${req.id}`,
        body: {
          status: screenshot ? 'captured' : 'failed',
          screenshot_id: screenshot?.id || null,
          completed_at: new Date().toISOString(),
        },
      });
    }
  } catch (err) {
    console.error('[MinuteFlow] Poll capture requests failed:', err.message);
  }
}

/**
 * Check for unread messages and show as toast notifications
 */
async function pollMessages() {
  const session = await DB.getSession();
  if (!session) return;

  try {
    const messages = await DB.query('messages', {
      filters: `target_user_id=eq.${session.user.id}&read=eq.false&order=created_at.asc`,
    });

    if (!messages || messages.length === 0) return;

    for (const msg of messages) {
      // Send to content script for toast display
      await showToast(msg.content, msg.sender_id);

      // Mark as read
      await DB.query('messages', {
        method: 'PATCH',
        filters: `id=eq.${msg.id}`,
        body: { read: true },
      });
    }
  } catch (err) {
    console.error('[MinuteFlow] Poll messages failed:', err.message);
  }
}

/**
 * Show a toast notification in the active tab
 */
async function showToast(message, senderId) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;

    // Skip chrome:// pages
    if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://'))) {
      // Fall back to chrome notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon-128.png',
        title: 'MinuteFlow',
        message: message,
      });
      return;
    }

    chrome.tabs.sendMessage(tab.id, {
      type: 'MINUTEFLOW_TOAST',
      message,
      senderId,
    });
  } catch (err) {
    // Fallback to browser notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon-128.png',
      title: 'MinuteFlow',
      message: message,
    });
  }
}

// ---------------------------------------------------------------------------
// Heartbeat
// ---------------------------------------------------------------------------

/**
 * Send heartbeat to server so admin knows the extension is active
 */
async function sendHeartbeat() {
  const session = await DB.getSession();
  if (!session) return;

  try {
    // Upsert heartbeat (unique on user_id)
    await DB.query('extension_heartbeats', {
      method: 'POST',
      body: {
        user_id: session.user.id,
        extension_version: CONFIG.VERSION,
        last_seen: new Date().toISOString(),
        is_active: true,
      },
      headers: {
        'Prefer': 'resolution=merge-duplicates,return=representation',
      },
    });
  } catch (err) {
    console.error('[MinuteFlow] Heartbeat failed:', err.message);
  }
}

// ---------------------------------------------------------------------------
// Polling Lifecycle
// ---------------------------------------------------------------------------

function startPolling() {
  if (pollingIntervalId) return; // Already running

  console.log('[MinuteFlow] Starting poll cycle');

  // Immediate first poll
  checkSessionState();
  pollCaptureRequests();
  pollMessages();
  sendHeartbeat();

  // Set up intervals
  pollingIntervalId = setInterval(() => {
    checkSessionState();
    pollCaptureRequests();
    pollMessages();
  }, CONFIG.POLL_INTERVAL_MS);

  heartbeatIntervalId = setInterval(() => {
    sendHeartbeat();
  }, CONFIG.HEARTBEAT_INTERVAL_MS);
}

function stopPolling() {
  console.log('[MinuteFlow] Stopping poll cycle');

  if (pollingIntervalId) {
    clearInterval(pollingIntervalId);
    pollingIntervalId = null;
  }
  if (heartbeatIntervalId) {
    clearInterval(heartbeatIntervalId);
    heartbeatIntervalId = null;
  }
  cancelCheckin();
}

// ---------------------------------------------------------------------------
// Session Monitoring
// ---------------------------------------------------------------------------

/**
 * Poll the user's current session to detect task start/end events.
 * This watches the `sessions` table for changes to `active_task`.
 */
let lastActiveTaskId = null;

async function checkSessionState() {
  const session = await DB.getSession();
  if (!session) return;

  try {
    const rows = await DB.query('sessions', {
      filters: `user_id=eq.${session.user.id}&limit=1`,
    });

    if (!rows || rows.length === 0) return;

    const userSession = rows[0];
    const activeTask = userSession.active_task;
    // Dashboard stores as "logId" (camelCase), handle both formats
    const taskLogId = activeTask ? (activeTask.logId || activeTask.log_id) : null;
    const parsedLogId = taskLogId ? parseInt(taskLogId, 10) || taskLogId : null;

    if (activeTask && parsedLogId) {
      // Task is active
      if (parsedLogId !== lastActiveTaskId) {
        // New task started (or changed)
        if (lastActiveTaskId) {
          // Previous task ended
          await onTaskEnd(lastActiveTaskId);
        }
        lastActiveTaskId = parsedLogId;
        await onTaskStart(parsedLogId);
      }
    } else {
      // No active task
      if (lastActiveTaskId) {
        await onTaskEnd(lastActiveTaskId);
        lastActiveTaskId = null;
      }
    }
  } catch (err) {
    console.error('[MinuteFlow] Session check failed:', err.message);
  }
}

// ---------------------------------------------------------------------------
// Message Handlers (from popup and content scripts)
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'MINUTEFLOW_LOGIN') {
    DB.signIn(msg.email, msg.password)
      .then((data) => {
        startPolling();
        sendResponse({ success: true, user: data.user });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message });
      });
    return true; // Async response
  }

  if (msg.type === 'MINUTEFLOW_LOGOUT') {
    stopPolling();
    DB.signOut()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (msg.type === 'MINUTEFLOW_GET_STATUS') {
    DB.getSession()
      .then(async (session) => {
        if (!session) {
          sendResponse({ loggedIn: false });
          return;
        }

        // Get profile info
        let profile = null;
        try {
          const profiles = await DB.query('profiles', {
            filters: `id=eq.${session.user.id}`,
          });
          profile = profiles?.[0] || null;
        } catch (_) {}

        sendResponse({
          loggedIn: true,
          user: session.user,
          profile,
          activeLogId: currentTaskLogId,
          polling: !!pollingIntervalId,
        });
      });
    return true;
  }

  if (msg.type === 'MINUTEFLOW_MANUAL_CAPTURE') {
    captureAndUpload('manual', msg.logId || currentTaskLogId)
      .then((screenshot) => {
        sendResponse({ success: !!screenshot, screenshot });
      })
      .catch((err) => {
        sendResponse({ success: false, error: err.message });
      });
    return true;
  }

  if (msg.type === 'MINUTEFLOW_TASK_START') {
    onTaskStart(msg.logId)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (msg.type === 'MINUTEFLOW_TASK_END') {
    onTaskEnd(msg.logId)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------

async function initialize() {
  console.log('[MinuteFlow] Extension initializing...');

  // Restore state
  const stored = await chrome.storage.local.get(['mf_active_log_id']);
  if (stored.mf_active_log_id) {
    currentTaskLogId = stored.mf_active_log_id;
    console.log(`[MinuteFlow] Restored active log: ${currentTaskLogId}`);
  }

  // Check if we have a valid session
  const session = await DB.ensureAuth();
  if (session) {
    console.log(`[MinuteFlow] Authenticated as ${session.user.email}`);
    startPolling();

    // If there's an active task, resume check-in timer
    if (currentTaskLogId) {
      scheduleNextCheckin();
    }
  } else {
    console.log('[MinuteFlow] Not authenticated — waiting for login');
  }
}

// Run on service worker start
initialize();

// Keep service worker alive with a recurring alarm
chrome.alarms.create('minuteflow-keepalive', { periodInMinutes: 0.5 });
